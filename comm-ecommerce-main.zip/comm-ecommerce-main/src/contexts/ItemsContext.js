import React, {createContext} from 'react'

const itemsContext = createContext('default ');
 
export default itemsContext;